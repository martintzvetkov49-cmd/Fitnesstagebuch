# Handoff: Fitness Tagebuch App

## Overview
A mobile-first fitness diary app for creating training plans, scheduling weekly workouts, tracking exercises with weight/reps during sessions, viewing training history via a calendar, and monitoring progress with charts. Dark blue theme.

## About the Design Files
The files in this bundle are **design references created in HTML** — interactive prototypes showing intended look and behavior, not production code to copy directly. The task is to **recreate these designs in the target codebase's existing environment** (React Native, Flutter, Swift, Kotlin, Next.js, etc.) using its established patterns and libraries — or, if no environment exists yet, to choose the most appropriate mobile-first framework and implement the designs there.

## Fidelity
**High-fidelity (hifi)**: Pixel-perfect mockups with final colors, typography, spacing, and interactions. Recreate the UI closely using the target codebase's libraries and patterns.

---

## Screens / Views

### 1. Home (Pläne Tab)
- **Purpose**: Overview of all training plans, quick stats, and today's scheduled workout
- **Layout**: Single-column, max-width 520px centered, 16px horizontal padding
- **Components**:
  - **Today's Workout Card** (conditional — shown if weekly schedule has a plan for today):
    - Gradient background: `rgba(59,130,246,0.10)` → `rgba(6,214,160,0.06)`, border `rgba(59,130,246,0.2)`
    - "HEUTE" badge: 10px uppercase, accent bg, 3px 8px padding
    - Plan name: 17px/700, exercise preview: 12px dim
    - "Jetzt starten" button: accent blue, 9px 20px padding, glow shadow
  - **Quick Stats Row** (3-column grid, 8px gap):
    - Cards: bg-card, radius-sm, border, 12px 10px padding
    - Value: 20px/700 mono, color-coded (accent, secondary, warm)
    - Label: 10px uppercase, text-dim
  - **Plan Cards** (stacked, 8px gap):
    - 40×40px icon badge: gradient accent→secondary, radius 10, dumbbell icon white
    - Title: 15px/600, subtitle: 12px dim with exercise names preview
    - Play button: 36×36 accent, radius 8
    - Bottom actions row: Edit, Copy, Delete — ghost buttons on bg-input, 11px, radius 6
  - **Create Plan Button**: dashed border 1.5px, 20px padding, "Neuer Trainingsplan"

### 2. Plan Editor
- **Purpose**: Create/edit training plans with exercises
- **Layout**: Single-column
- **Components**:
  - **Plan Name Input**: 18px/700, transparent bg, bottom border 2px, focuses to accent
  - **Exercise Cards** (collapsible accordion, one open at a time):
    - Collapsed: `#N` badge (mono 11px, accent on accent-glow bg), exercise name 14px/600, summary "3×10 · 80kg" mono 11px, chevron ▾
    - Expanded: border turns accent, glow shadow, reveals:
      - Move ▲▼ buttons, delete trash button
      - Name input: 14px/600
      - 3-column grid (Sätze/Wdh./Gewicht): Label 11px uppercase, input centered mono
      - Notes input: 12px dim
    - Animation: max-height 0→400, opacity, margin-top transition 0.3s
  - **Add Exercise Buttons** (2-col flex): "Manuell" + "Bibliothek" ghost buttons
  - **Start Button**: full-width gradient accent→secondary, glow shadow, 15px

### 3. Exercise Library (Modal)
- **Purpose**: Pick from 50+ predefined exercises by muscle group
- **Layout**: Bottom sheet modal, 80vh max, rounded top 20px
- **Components**:
  - Drag handle: 40×4px rounded, border color
  - Search input
  - Group filter pills (horizontal scroll): Brust(red), Rücken(blue), Schultern(amber), Beine(green), Arme(purple), Core(pink)
  - Exercise list grouped by muscle: colored dot 8px, name 14px, default sets/reps mono 12px
  - Backdrop: rgba(0,0,0,0.7) + blur(4px)

### 4. Workout Session
- **Purpose**: Track sets, weight, and reps during active training
- **Layout**: Single-column
- **Components**:
  - **Progress Bar**: 5px height, gradient accent→secondary, label "X/Y" mono
  - **Exercise Pills** (horizontal scroll): active=accent fill, done=green tint + ✓
  - **Rest Timer**:
    - SVG circle progress (52×52), countdown mono 13px
    - States: idle, running (accent border), finished (green bg tint)
    - Start/Pause/Reset/Continue buttons
    - Duration presets dropdown: 30s, 60s, 90s, 2m, 3m
  - **Exercise Card**:
    - Name: 18px/700, notes: 12px dim
    - Set grid: 4 columns (Satz 36px | kg 1fr | Wdh. 1fr | check 42px)
    - Labels: 11px uppercase muted
    - Inputs: centered mono 14px, opacity 0.5 when done
    - Check button: 34×34 radius 8, toggles bg-input↔accent-secondary
  - **Navigation**: "← Vorherige" ghost, "Nächste →" accent, or "Fertig" gradient

### 5. Weekly Schedule (Woche Tab)
- **Purpose**: Assign training plans to each day of the week
- **Layout**: 7 rows stacked, 6px gap
- **Components**:
  - **Today's Workout** (top card, conditional): gradient bg, plan name 18px/700, exercises list, start button
  - **Day Rows**:
    - Day badge: 36×36 radius 8, mono 12px/700 (today=accent fill white, assigned=accent tint, empty=bg-input muted)
    - Content: plan name or "Ruhetag" 14px, exercise count 11px
    - Edit button: "Ändern" or "+ Plan", 11px, border ghost
    - Today row: highlighted border accent, bg-card-hover
  - **Plan Picker** (inline dropdown on edit): list of plans as buttons, "Ruhetag" danger option

### 6. History (Historie Tab)
- **Purpose**: Calendar view of past workouts with detail drill-down
- **Layout**: Calendar + stats + detail
- **Components**:
  - **Month Calendar**: grid 7 cols, day buttons aspect-ratio 1, radius 8
    - Has log: blue tint bg, green dot 4px bottom
    - Today: accent text, bold
    - Selected: accent fill white text
    - Month nav: ← arrows
  - **Stats Row** (3-col): Trainings this month / total / active plans — 24px mono accent values
  - **Day Detail** (on select): plan cards with exercise logs showing completed sets as pills "80kg × 10"

### 7. Progress Charts (Stats Tab)
- **Purpose**: Weight progression per exercise over time
- **Layout**: Exercise selector → chart → stat cards
- **Components**:
  - **Exercise Selector Pills**: horizontal scroll, active=accent
  - **Chart Card**: SVG line chart (viewBox 460×180)
    - Grid lines dashed, Y-axis labels mono
    - Area fill with gradient opacity 0.3
    - Line: accent 2.5px, dots: accent 4r with card-color stroke
    - Date labels: first and last, mono 10px
    - Improvement badge: "+X.X%" green or red
  - **Stat Cards** (2×2 grid): Best weight, sessions, last weight, last volume

---

## Interactions & Behavior
- **Accordion**: only one exercise expanded at a time; toggle with smooth max-height/opacity transition (0.3s ease)
- **Plan cards**: border + glow on hover
- **Buttons**: all have `transition: all 0.2s`
- **Input focus**: border-color transitions to accent
- **Bottom sheet modal**: overlay click to close, stopPropagation on content
- **Timer**: circular SVG progress, auto-stop at 0, vibrate on finish (`navigator.vibrate`)
- **Data persistence**: all data in localStorage, auto-saves on every state change
- **Navigation**: bottom tab bar with 4 tabs, sub-views (editor, workout) replace main content with back button

## State Management
- **Global state** (`data`): `{ plans: Plan[], logs: Record<string, SessionData>, weeklySchedule: Record<number, string> }`
- **Plan**: `{ id, name, exercises: Exercise[] }`
- **Exercise**: `{ id, name, sets, reps, weight, notes }`
- **SessionData**: array per plan-exercise, each with `sets: { weight, reps, done }[]`
- **Log keys**: `{planId}_{YYYY-MM-DD}`
- **View routing**: `view` (home|editPlan|workout) + `tab` (home|week|history|progress)

## Design Tokens

### Colors
| Token | Value |
|---|---|
| bg-deep | `#080c16` |
| bg-card | `#0f1525` |
| bg-card-hover | `#151d30` |
| bg-input | `#0b1020` |
| border | `#1a2340` |
| accent | `#3b82f6` |
| accent-glow | `rgba(59,130,246,0.25)` |
| accent-secondary | `#06d6a0` |
| accent-warm | `#f59e0b` |
| text | `#e2e8f0` |
| text-dim | `#64748b` |
| text-muted | `#3e4c6a` |
| danger | `#ef4444` |

### Typography
| Usage | Font | Size | Weight |
|---|---|---|---|
| Primary | Space Grotesk | — | 400–700 |
| Mono (numbers) | JetBrains Mono | — | 400–500 |
| Page title | Space Grotesk | 24px | 700 |
| Section title | Space Grotesk | 18–20px | 700 |
| Card title | Space Grotesk | 15px | 600 |
| Body | Space Grotesk | 14px | 400–500 |
| Label | Space Grotesk | 11px | 700, uppercase |
| Small | Space Grotesk | 12px | 400–600 |
| Nav | Space Grotesk | 10px | 600 |

### Spacing & Radius
| Token | Value |
|---|---|
| radius | 14px |
| radius-sm | 10px |
| card padding | 18px |
| page padding | 16px |
| grid gaps | 6–8px |

### Shadows
- Accent glow: `0 0 24px rgba(59,130,246,0.25)`
- Button glow: `0 2px 16px rgba(59,130,246,0.25)`
- CTA glow: `0 4px 20px rgba(59,130,246,0.25)`

## Exercise Library Categories
Brust (6), Rücken (7), Schultern (6), Beine (8), Arme (7), Core (6) — see `exercise-library.jsx` for full list.

## Files
| File | Description |
|---|---|
| `Fitness Tagebuch v3.html` | Main app (App, Home, PlanEditor, WorkoutView) |
| `components/exercise-library.jsx` | Exercise library data + modal |
| `components/rest-timer.jsx` | Circular rest timer |
| `components/history-view.jsx` | Calendar + history detail |
| `components/progress-view.jsx` | SVG charts + stats |
| `components/weekly-schedule.jsx` | Weekly plan assignment |
| `tweaks-panel.jsx` | Design tweaks panel (dev-only) |
